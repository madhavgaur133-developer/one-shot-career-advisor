One-Stop Personalized Career & Education Advisor — Expanded Prototype (v2)

This expanded prototype includes:
- Auth (signup/login with JWT)
- Interest & aptitude quizzes + mapping to streams
- Course-to-career mappings
- Colleges directory with admin add endpoint (simple API key)
- Timeline/reminder creation per user

Backend (Node.js + lowdb v3)
- cd backend
- npm install
- npm start
- Runs on http://localhost:4000

Frontend
- Open frontend/index.html in a browser (it talks to the backend on localhost:4000)
- For production, build a React/Vite app and serve via backend or a static hosting.

Admin
- Use apiKey 'admin_secret' when calling POST /api/admin/college to add new colleges (prototype only).

Notes
- This is still a prototype. For production: use a real DB (Postgres/Mongo), proper auth/roles, input validation, HTTPS, push notifications, geolocation services, and analytics.