const API = window.location.hostname === 'localhost' || window.location.hostname==='127.0.0.1' ? 'http://localhost:4000/api' : '/api';
let state = { token:null, user:null };

function show(id){
  document.querySelectorAll('.view').forEach(v=> v.style.display='none');
  document.getElementById(id).style.display='block';
  if(id==='quiz') loadQuiz();
  if(id==='colleges') loadColleges();
  if(id==='timeline') loadMyTimelines();
}

async function signup(){
  const name = document.getElementById('su_name').value;
  const email = document.getElementById('su_email').value;
  const password = document.getElementById('su_password').value;
  const res = await fetch(API + '/auth/signup', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name,email,password})});
  const data = await res.json();
  if(data.token){ state.token = data.token; state.user = data.user; document.getElementById('authMsg').innerText = 'Signed up and logged in.'; }
  else document.getElementById('authMsg').innerText = JSON.stringify(data);
}

async function login(){
  const email = document.getElementById('li_email').value;
  const password = document.getElementById('li_password').value;
  const res = await fetch(API + '/auth/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})});
  const data = await res.json();
  if(data.token){ state.token = data.token; state.user = data.user; document.getElementById('authMsg').innerText = 'Logged in.'; }
  else document.getElementById('authMsg').innerText = JSON.stringify(data);
}

async function loadQuiz(){
  const res = await fetch(API + '/quizzes');
  const quizzes = await res.json();
  const qdiv = document.getElementById('quizArea'); qdiv.innerHTML='';
  quizzes.forEach(q=>{
    const h = document.createElement('h3'); h.innerText = q.title; qdiv.appendChild(h);
    q.questions.forEach(qq=>{
      const p = document.createElement('p'); p.innerText = qq.text; qdiv.appendChild(p);
      qq.options.forEach(opt=>{
        const cb = document.createElement('input'); cb.type='checkbox'; cb.id=opt.id; cb.value=opt.id; cb.name='qopt';
        const lbl = document.createElement('label'); lbl.htmlFor=opt.id; lbl.innerText = ' '+opt.text;
        qdiv.appendChild(cb); qdiv.appendChild(lbl); qdiv.appendChild(document.createElement('br'));
      });
    });
  });
}

async function submitQuiz(){
  const checked = Array.from(document.querySelectorAll('input[name=qopt]:checked')).map(i=>i.value);
  if(checked.length===0) return alert('Choose at least one');
  const res = await fetch(API + '/quizzes/submit', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({answers:checked})});
  const data = await res.json();
  const out = document.getElementById('quizResults'); out.innerHTML = '<h4>Recommended Streams: '+ (data.recommendations||[]).join(', ') +'</h4>';
  if(data.mappings) out.innerHTML += '<pre>'+ JSON.stringify(data.mappings, null, 2) +'</pre>';
}

async function loadColleges(){
  const stream = document.getElementById('filterStream').value;
  const url = API + '/colleges' + (stream ? '?stream=' + encodeURIComponent(stream) : '');
  const res = await fetch(url);
  const cols = await res.json();
  const d = document.getElementById('collegesList');
  d.innerHTML = cols.map(c=>`<div class="card"><h4>${c.name} — ${c.city}</h4><p>Programs: ${c.programs.join(', ')}</p><p>Streams: ${c.streams.join(', ')}</p><p>Facilities: ${c.facilities.join(', ')}</p></div>`).join('');
}

async function addTimeline(){
  if(!state.user) return alert('Login first');
  const title = document.getElementById('tl_title').value;
  const date = document.getElementById('tl_date').value;
  const note = document.getElementById('tl_note').value;
  if(!title||!date) return alert('Title/date required');
  const res = await fetch(API + '/timelines', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({userId:state.user.id, tokenTitle:title, date, note})});
  const data = await res.json();
  document.getElementById('myTimelines').innerText = 'Added: ' + JSON.stringify(data);
}

async function loadMyTimelines(){
  if(!state.user){ document.getElementById('myTimelines').innerText = 'Login to see timelines.'; return; }
  const res = await fetch(API + '/timelines/' + state.user.id);
  const list = await res.json();
  document.getElementById('myTimelines').innerHTML = list.length ? '<ul>' + list.map(i=>`<li>${i.date} — ${i.title} — ${i.note||''}</li>`).join('') + '</ul>' : 'No reminders';
}

async function addCollege(){
  const name = document.getElementById('ad_name').value;
  const city = document.getElementById('ad_city').value;
  const streams = (document.getElementById('ad_streams').value||'').split(',').map(s=>s.trim()).filter(Boolean);
  const programs = (document.getElementById('ad_programs').value||'').split(',').map(s=>s.trim()).filter(Boolean);
  const payload = { apiKey:'admin_secret', college:{ name, city, streams, programs, eligibility:'10+2', facilities:[] } };
  const res = await fetch(API + '/admin/college', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const data = await res.json();
  document.getElementById('adminMsg').innerText = JSON.stringify(data);
}