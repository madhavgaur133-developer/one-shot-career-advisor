/**
 Expanded backend (prototype)
 - Auth with JWT (signup/login)
 - Users, Quizzes, Colleges, Course->Career mapping
 - Timeline reminders, Admin endpoints
 - Uses lowdb v3 (async JSONFile)
*/
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const SECRET = process.env.JWT_SECRET || 'dev_secret_key';

// Setup lowdb v3
const dbFile = path.join(__dirname, 'data', 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

async function initDB(){
  await db.read();
  db.data = db.data || { users: [], colleges: [], quizzes: [], timelines: [], mappings: [] };

  // seed sample data if empty
  if (!db.data.colleges || db.data.colleges.length===0) {
    db.data.colleges = [
      { id:'govcol1', name:'Government Degree College, Srinagar', city:'Srinagar', streams:['Science','Arts','Commerce'], programs:['B.Sc','B.A','B.Com'], eligibility:'10+2 pass', cutoff:'Varies', facilities:['Library','Labs','Hostel'], coords:{lat:34.08, lng:74.79} },
      { id:'govcol2', name:'Government Degree College, Jammu', city:'Jammu', streams:['Arts','Commerce','Vocational'], programs:['B.A','B.Com','Diploma in Hospitality'], eligibility:'10+2 pass', cutoff:'Varies', facilities:['Library','Internet'], coords:{lat:32.73, lng:74.84} }
    ];
  }
  if (!db.data.quizzes || db.data.quizzes.length===0){
    db.data.quizzes = [
      {
        id:'q1', title:'Interest & Aptitude - Short', questions:[
          { id:'q1_1', text:'Select activities you enjoy', options:[
            {id:'math_science', text:'Math & logical problems'}, {id:'experiments', text:'Experiments/labs'}, {id:'drawing', text:'Drawing or performing arts'},
            {id:'writing', text:'Writing & languages'}, {id:'business', text:'Buying/selling, starting ventures'}, {id:'accounts', text:'Working with numbers/accounts'},
            {id:'vocational', text:'Hands-on skills (IT, hospitality)'} ] }
        ]
      }
    ];
  }
  if (!db.data.mappings || db.data.mappings.length===0){
    db.data.mappings = [
      { stream:'Science', courses:['B.Sc','BCA','B.Tech'], careers:['Research','IT','Engineering','Teaching'], exams:['JEE','NET','GATE'] },
      { stream:'Arts', courses:['B.A','B.Ed'], careers:['Civil Services','Teaching','Media'], exams:['UPSC','State PSC'] },
      { stream:'Commerce', courses:['B.Com','BBA'], careers:['Accounting','Business','Banking'], exams:['CA','CMA','Bank PO'] },
      { stream:'Vocational', courses:['Diploma - IT, Hospitality'], careers:['Hospitality','Skilled Technician'], exams:[] }
    ];
  }
  if(!db.data.users) db.data.users = [];
  if(!db.data.timelines) db.data.timelines = [];
  await db.write();
}
initDB();

// Helpers
function generateToken(user){ return jwt.sign({id:user.id, name:user.name, role:user.role||'student'}, SECRET, {expiresIn:'7d'}); }
async function getUserFromToken(req){
  const auth = req.headers.authorization;
  if(!auth) return null;
  const parts = auth.split(' ');
  if(parts.length!==2) return null;
  try{
    const payload = jwt.verify(parts[1], SECRET);
    await db.read();
    return db.data.users.find(u=>u.id===payload.id) || null;
  }catch(e){ return null; }
}

// Routes
app.get('/api/health', (req,res)=> res.json({status:'ok', version:'2.0'}));

// Auth: signup & login
app.post('/api/auth/signup', async (req,res)=>{
  const {name, email, password, age, classLevel, gender} = req.body;
  if(!name || !email || !password) return res.status(400).json({error:'name,email,password required'});
  await db.read();
  const exists = db.data.users.find(u=>u.email===email);
  if(exists) return res.status(400).json({error:'email already registered'});
  const hashed = await bcrypt.hash(password, 8);
  const user = { id: nanoid(), name, email, password:hashed, age, classLevel, gender, role:'student', createdAt:new Date().toISOString() };
  db.data.users.push(user);
  await db.write();
  const token = generateToken(user);
  res.json({user:{id:user.id,name:user.name,email:user.email,role:user.role}, token});
});

app.post('/api/auth/login', async (req,res)=>{
  const {email, password} = req.body;
  if(!email || !password) return res.status(400).json({error:'email,password required'});
  await db.read();
  const user = db.data.users.find(u=>u.email===email);
  if(!user) return res.status(400).json({error:'invalid'});
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(400).json({error:'invalid'});
  const token = generateToken(user);
  res.json({user:{id:user.id,name:user.name,email:user.email,role:user.role}, token});
});

// Public: quizzes, colleges, mapping
app.get('/api/quizzes', async (req,res)=>{
  await db.read(); res.json(db.data.quizzes || []);
});

app.post('/api/quizzes/submit', async (req,res)=>{
  // simple rule-based mapping similar to earlier, but enhanced
  const answers = req.body.answers || [];
  await db.read();
  const score = {};
  answers.forEach(a=> score[a]= (score[a]||0) + 1);
  const map = {
    'math_science':['Science'],
    'experiments':['Science'],
    'drawing':['Arts'],
    'writing':['Arts'],
    'business':['Commerce'],
    'accounts':['Commerce'],
    'vocational':['Vocational']
  };
  const streamScores = {};
  for(const k in score){
    (map[k]||[]).forEach(s=> streamScores[s] = (streamScores[s]||0) + score[k]);
  }
  const max = Math.max(...Object.values(streamScores), 0);
  const recs = Object.keys(streamScores).filter(s=>streamScores[s]===max);
  const mappings = db.data.mappings.filter(m=> recs.includes(m.stream));
  res.json({recommendations: recs, mappings});
});

app.get('/api/colleges', async (req,res)=>{
  await db.read();
  const stream = req.query.stream;
  let cols = db.data.colleges || [];
  if(stream) cols = cols.filter(c=> c.streams.includes(stream));
  res.json(cols);
});

app.get('/api/colleges/:id', async (req,res)=>{
  await db.read();
  const c = db.data.colleges.find(x=>x.id===req.params.id);
  if(!c) return res.status(404).json({error:'not found'});
  res.json(c);
});

// timelines
app.post('/api/timelines', async (req,res)=>{
  const { tokenTitle, date, note, userId } = req.body;
  if(!userId || !tokenTitle || !date) return res.status(400).json({error:'userId,title,date required'});
  await db.read();
  const item = { id:nanoid(), userId, title:tokenTitle, date, note, createdAt:new Date().toISOString() };
  db.data.timelines.push(item);
  await db.write();
  res.json(item);
});
app.get('/api/timelines/:userId', async (req,res)=>{
  await db.read();
  const list = db.data.timelines.filter(t=>t.userId===req.params.userId);
  res.json(list);
});

// Admin endpoints (simple role check)
app.post('/api/admin/college', async (req,res)=>{
  const { apiKey, college } = req.body;
  // For prototype: simple apiKey check; replace with auth in prod
  if(apiKey !== 'admin_secret') return res.status(403).json({error:'unauthorized'});
  await db.read();
  college.id = college.id || nanoid();
  db.data.colleges.push(college);
  await db.write();
  res.json(college);
});

// Serve frontend static in production (optional)
app.use('/', express.static(path.join(__dirname, '..', 'frontend_build')));

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Server running on', PORT));